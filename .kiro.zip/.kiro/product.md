# Product Vision: AWS Compute Referee

## Purpose
A decision-support tool that helps developers choose between AWS Lambda (Serverless) and AWS EC2 (Virtual Machines) based on their specific constraints.

## Core Features
1. **User Input Profile**: Users enter their expected traffic, budget, and execution duration.
2. **Comparison Engine**: 
   - Calculates estimated costs for both services.
   - Evaluates operational overhead (Maintenance).
3. **Trade-off Analysis**: 
   - If Lambda is chosen: Mention 'Cold Starts' as a trade-off.
   - If EC2 is chosen: Mention 'Management Overhead' and 'Idle Cost' as trade-offs.
4. **Final Recommendation**: A non-biased summary table.

## Target Audience
DevOps Engineers and Startup Founders using AWS.
